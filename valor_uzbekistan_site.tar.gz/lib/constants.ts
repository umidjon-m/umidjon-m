/*
  Constants used across the application

  This file centralises all textual content and link definitions for the
  Valor Uzbekistan website. Storing these values in one place makes it
  easier to update copy without touching component logic and ensures
  consistency across the site. All text is written in Uzbek to match
  the target audience.
*/

export const LINKS = {
  catalogue: 'https://t.me/valor_uz',
  manager: 'https://t.me/valor_menejer',
  channel: 'https://t.me/valor_uzbekistan',
  instagram: 'https://www.instagram.com/valor.uzbekistan',
  youtube: 'https://www.youtube.com/@valor.uzbekistan',
  taplink: 'https://taplink.cc/valor.uzbekistan',
  phone: '+998954608888',
};

export const HERO_CONTENT = {
  title: 'Valor Uzbekistan',
  subtitle: 'Qurilish materiallari bo‘yicha ishonchli distribyutor',
  description:
    'Do‘konlar, ustalar va qurilish obyektlari uchun 4000+ turdagi mahsulotlar, tezkor yetkazib berish va ishonchli ta’minotni taklif qilamiz.',
  ctaPrimary: {
    label: 'Katalogni ko‘rish',
    href: LINKS.catalogue,
  },
  ctaSecondary: {
    label: 'Menejer bilan bog‘lanish',
    href: LINKS.manager,
  },
  stats: [
    {
      title: '4000+',
      description: 'turli mahsulot',
    },
    {
      title: 'Tezkor',
      description: 'yetkazib berish',
    },
    {
      title: 'Ishonchli',
      description: 'ta’minot',
    },
    {
      title: 'Qulay',
      description: 'hamkorlik',
    },
  ],
};

export const ABOUT_CONTENT = {
  heading: 'Kerakli mahsulotlar, qulay aloqa, ishonchli hamkorlik',
  description:
    'Valor Uzbekistan qurilish materiallari bo‘yicha ishonchli distribyutor sifatida do‘konlar, ustalar va qurilish obyektlari uchun keng assortimentdagi mahsulotlarni taklif qiladi. Bizning maqsadimiz — mahsulot tanlashdan buyurtmagacha bo‘lgan jarayonni qulay, tez va ishonchli qilish.',
};

export const BENEFITS = [
  {
    title: '4000+ mahsulot',
    description: 'Qurilish va ta’mirlash yo‘nalishlari bo‘yicha keng assortiment.',
  },
  {
    title: 'Tezkor yetkazib berish',
    description: 'Buyurtmalarni imkon qadar tez va qulay tarzda yetkazamiz.',
  },
  {
    title: 'Ishonchli ta’minot',
    description: 'Do‘konlar va obyektlar uchun barqaror va ishonchli hamkorlik.',
  },
  {
    title: 'Qulay hamkorlik',
    description: 'Katalog, Telegram, telefon va boshqa kanallar orqali tez buyurtma.',
  },
];

export const DIRECTIONS = {
  products: [
    {
      title: 'Qurilish materiallari',
      description: 'Asosiy va yordamchi qurilish mahsulotlari.',
    },
    {
      title: 'Santexnika',
      description: 'Santexnika yo‘nalishidagi mahsulotlar.',
    },
  ],
  actions: [
    {
      title: 'Telegram katalog',
      description: 'Mahsulotlar bilan tanishing',
      href: LINKS.catalogue,
    },
    {
      title: 'Onlayn buyurtma',
      description: 'Menejer bilan tez bog‘laning',
      href: LINKS.manager,
    },
  ],
};

export const PROCESS_STEPS = [
  {
    title: 'Katalogni ko‘ring',
    description: 'Mahsulotlar assortimentini ko‘zdan kechiring.',
  },
  {
    title: 'Mahsulotni tanlang',
    description: 'Sizga mos mahsulotni yoki yo‘nalishni tanlang.',
  },
  {
    title: 'Menejerga yozing',
    description: 'Buyurtma va savollar bo‘yicha bog‘laning.',
  },
  {
    title: 'Buyurtmani tasdiqlang',
    description: 'Ma’lumotlarni aniqlab, buyurtmani rasmiylashtiring.',
  },
  {
    title: 'Tez yetkazib oling',
    description: 'Buyurtmani qulay tarzda yetkazib oling.',
  },
];

export const CONTACT_SECTIONS = {
  primary: [
    {
      label: 'Mahsulot katalogi',
      description: 'Keng assortimentni ko‘ring',
      href: LINKS.catalogue,
    },
    {
      label: 'Menejer bilan bog‘lanish',
      description: 'Buyurtma va savollar uchun',
      href: LINKS.manager,
    },
    {
      label: 'Telefon orqali bog‘lanish',
      description: 'Tez aloqa uchun qo‘ng‘iroq qiling',
      href: `tel:${LINKS.phone}`,
    },
  ],
  secondary: [
    {
      label: 'Telegram kanal',
      description: 'Yangiliklar va aksiyalar',
      href: LINKS.channel,
    },
    {
      label: 'Instagram',
      description: 'Bizni kuzating',
      href: LINKS.instagram,
    },
    {
      label: 'YouTube',
      description: 'Video ko‘rinishlar',
      href: LINKS.youtube,
    },
  ],
};

export const FINAL_CTA = {
  heading: 'Buyurtma yoki hamkorlik uchun hoziroq bog‘laning',
  description:
    'Kerakli mahsulotni katalog orqali tanlang yoki menejer bilan to‘g‘ridan-to‘g‘ri bog‘laning.',
  primary: {
    label: 'Katalogni ko‘rish',
    href: LINKS.catalogue,
  },
  secondary: {
    label: 'Menejer bilan bog‘lanish',
    href: LINKS.manager,
  },
};