import './globals.css';
import type { Metadata } from 'next';
import { inter } from 'next/font/google';

/*
  Root layout component

  This file defines the base HTML structure for every page of the app.
  We import our global CSS and apply the Inter font from Google Fonts
  (subset latin-ext for Uzbek). The metadata object provides default
  SEO values including title, description and Open Graph tags. These
  values can be overridden by individual pages if needed. The html
  element uses the 'dark' class to enable Tailwind's dark mode.
*/

// Load Inter font with Uzbek support
const interFont = inter({ subsets: ['latin-ext'], display: 'swap' });

export const metadata: Metadata = {
  title: 'Valor Uzbekistan | Qurilish materiallari bo‘yicha ishonchli distribyutor',
  description:
    '4000+ mahsulot, tezkor yetkazib berish va ishonchli ta’minot. Valor Uzbekistan qurilish materiallari va santexnika mahsulotlari bo‘yicha ishonchli distribyutor.',
  openGraph: {
    title: 'Valor Uzbekistan',
    description:
      'Qurilish materiallari bo‘yicha ishonchli distribyutor. 4000+ mahsulot, tezkor yetkazib berish va ishonchli ta’minot.',
    type: 'website',
    locale: 'uz_UZ',
    url: 'https://valor.uzbekistan',
    siteName: 'Valor Uzbekistan',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Valor Uzbekistan',
    description:
      'Qurilish materiallari bo‘yicha ishonchli distribyutor. 4000+ mahsulot, tezkor yetkazib berish va ishonchli ta’minot.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="uz" className="dark">
      <body className={interFont.className + ' min-h-screen overflow-x-hidden bg-brand-dark text-brand-white'}>
        {children}
      </body>
    </html>
  );
}