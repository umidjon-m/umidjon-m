import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import HeroSection from "@/components/sections/HeroSection";
import AboutSection from "@/components/sections/AboutSection";
import BenefitsSection from "@/components/sections/BenefitsSection";
import DirectionsSection from "@/components/sections/DirectionsSection";
import ProcessSection from "@/components/sections/ProcessSection";
import ContactSection from "@/components/sections/ContactSection";
import FinalCTASection from "@/components/sections/FinalCTASection";

/**
 * Main landing page component. Assembles all sections in order and
 * renders the global header and footer. Sections are separated by
 * consistent spacing and borders defined in each component.
 */
export default function Page() {
  return (
    <>
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <BenefitsSection />
        <DirectionsSection />
        <ProcessSection />
        <ContactSection />
        <FinalCTASection />
      </main>
      <Footer />
    </>
  );
}