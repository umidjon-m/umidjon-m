import Container from "../ui/Container";
import SectionHeading from "../ui/SectionHeading";
import { PROCESS_STEPS } from "@/lib/constants";

/**
 * ProcessSection outlines the typical workflow when working with Valor Uzbekistan.
 * It presents each step in a vertical list with a numbered circle indicator.
 */
export default function ProcessSection() {
  return (
    <section
      id="process"
      className="py-16 sm:py-24 border-t border-white/10"
    >
      <Container>
        <SectionHeading
          title="Biz bilan ishlash tartibi"
          description="Ta’minot jarayoni sodda va oshkora"
        />
        <ol className="mt-12 space-y-8">
          {PROCESS_STEPS.map((step, index) => (
            <li key={step.title} className="relative pl-12">
              <span className="absolute left-0 top-0 flex h-8 w-8 items-center justify-center rounded-full bg-brand-red text-sm font-bold text-white">
                {index + 1}
              </span>
              <h3 className="text-lg font-semibold text-white">
                {step.title}
              </h3>
              <p className="mt-1 text-sm text-brand-lightGray">
                {step.description}
              </p>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  );
}