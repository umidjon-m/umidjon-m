import Container from "../ui/Container";
import SectionHeading from "../ui/SectionHeading";
import { ABOUT_CONTENT } from "@/lib/constants";

/**
 * AboutSection provides a brief introduction to the company. It leverages
 * SectionHeading for consistent typography and spacing. The content is
 * defined in constants for easy updates.
 */
export default function AboutSection() {
  return (
    <section id="about" className="py-16 sm:py-24">
      <Container>
        <SectionHeading
          title={ABOUT_CONTENT.heading}
          description={ABOUT_CONTENT.description}
        />
      </Container>
    </section>
  );
}