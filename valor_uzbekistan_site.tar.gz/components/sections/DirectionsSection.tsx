import Container from "../ui/Container";
import SectionHeading from "../ui/SectionHeading";
import InfoCard from "../ui/InfoCard";
import { DIRECTIONS } from "@/lib/constants";

/**
 * DirectionsSection displays product categories and key actions for visitors.
 * It divides the content into two grids: one for product directions and one for
 * call‑to‑action links such as the Telegram catalog and online order.
 */
export default function DirectionsSection() {
  return (
    <section
      id="directions"
      className="py-16 sm:py-24 border-t border-white/10"
    >
      <Container>
        <SectionHeading
          title="Mahsulot va aloqa yo‘llari bir joyda"
          description="Kerakli yo‘nalishni tanlang yoki darhol bog‘laning"
        />
        {/* Product categories */}
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {DIRECTIONS.products.map((item) => (
            <InfoCard
              key={item.title}
              title={item.title}
              description={item.description}
            />
          ))}
        </div>
        {/* Action links */}
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {DIRECTIONS.actions.map((item) => (
            <InfoCard
              key={item.title}
              title={item.title}
              description={item.description}
              link={item.href}
              linkLabel="Batafsil"
            />
          ))}
        </div>
      </Container>
    </section>
  );
}