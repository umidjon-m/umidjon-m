import Container from "../ui/Container";
import SectionHeading from "../ui/SectionHeading";
import InfoCard from "../ui/InfoCard";
import { BENEFITS } from "@/lib/constants";

/**
 * BenefitsSection displays key advantages of partnering with Valor Uzbekistan.
 * Four InfoCards are laid out in a responsive grid. A header introduces
 * the section.
 */
export default function BenefitsSection() {
  return (
    <section id="benefits" className="py-16 sm:py-24 border-t border-white/10">
      <Container>
        <SectionHeading
          title="Nega aynan Valor Uzbekistan"
          description="Quyidagi afzalliklar bizning hamkorligimizni yanada ishonchli qiladi"
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {BENEFITS.map((benefit) => (
            <InfoCard
              key={benefit.title}
              title={benefit.title}
              description={benefit.description}
            />
          ))}
        </div>
      </Container>
    </section>
  );
}