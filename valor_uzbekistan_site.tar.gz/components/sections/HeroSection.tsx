"use client";

import Image from "next/image";
import Button from "../ui/Button";
import Badge from "../ui/Badge";
import StatItem from "../ui/StatItem";
import Container from "../ui/Container";
import {
  HERO_CONTENT,
  CONTACT_SECTIONS,
} from "@/lib/constants";

/**
 * HeroSection: the first and most prominent section of the landing page.
 * It establishes the brand and key value propositions. Includes a badge,
 * heading, subheading, description, call‑to‑action buttons, and stats.
 */
export default function HeroSection() {
  // Derive hero data from constants. Destructure for clarity.
  const hero = {
    title: HERO_CONTENT.title,
    subtitle: HERO_CONTENT.subtitle,
    description: HERO_CONTENT.description,
    ctas: [
      {
        label: HERO_CONTENT.ctaPrimary.label,
        link: HERO_CONTENT.ctaPrimary.href,
        variant: "primary",
        external: true,
      },
      {
        label: HERO_CONTENT.ctaSecondary.label,
        link: HERO_CONTENT.ctaSecondary.href,
        variant: "secondary",
        external: true,
      },
    ],
    // Convert stats to value/label pairs
    stats: HERO_CONTENT.stats.map((s) => ({
      value: s.title,
      label: s.description,
    })),
    // Use primary contact items as panel items for trust signals
    panelItems: CONTACT_SECTIONS.primary.map((item) => ({
      title: item.label,
      description: item.description,
    })),
    badge: HERO_CONTENT.subtitle,
  };
  return (
    <section id="hero" className="relative overflow-hidden pb-24 pt-32 sm:pt-40">
      <Container className="relative z-10 grid items-center gap-12 md:grid-cols-2">
        {/* Left column: text */}
        <div className="space-y-6">
          {hero.badge && <Badge>{hero.badge}</Badge>}
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
            {hero.title}
          </h1>
          <p className="text-brand-lightGray md:text-lg">
            {hero.description}
          </p>
          {/* CTA buttons */}
          <div className="mt-8 flex flex-col gap-4 sm:flex-row">
            {hero.ctas.map((cta) => (
              <Button
                key={cta.label}
                href={cta.link}
                variant={cta.variant === "secondary" ? "secondary" : "primary"}
                external={cta.external}
              >
                {cta.label}
              </Button>
            ))}
          </div>
          {/* Stats */}
          <dl className="mt-10 grid grid-cols-2 gap-x-8 gap-y-6 sm:gap-x-12 md:gap-x-16 lg:max-w-lg">
            {hero.stats.map((stat) => (
              <StatItem key={stat.label} value={stat.value} label={stat.label} />
            ))}
          </dl>
        </div>
        {/* Right column: decorative panel */}
        <div className="relative hidden md:block">
          {/* Panel container with subtle gradient and glow */}
          <div className="relative flex flex-col gap-4 rounded-3xl bg-brand-charcoal/80 p-6 shadow-lg shadow-brand-red/20 backdrop-blur">
            {/* Info items to showcase quick links and trust signals */}
            {hero.panelItems.map((item, idx) => (
              <div key={idx} className="flex items-start gap-3 rounded-xl border border-white/10 bg-brand-dark px-4 py-3">
                {/* Icon placeholder: red dot */}
                <span className="mt-1 h-2 w-2 rounded-full bg-brand-red"></span>
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-white">
                    {item.title}
                  </span>
                  <span className="text-xs text-brand-lightGray">
                    {item.description}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Container>
      {/* Background glow */}
      <div
        aria-hidden="true"
        className="absolute inset-0 -z-10 overflow-hidden"
      >
        <div className="absolute left-1/2 top-0 h-[120%] w-[150%] -translate-x-1/2 rounded-full bg-brand-red/10 blur-3xl"></div>
      </div>
    </section>
  );
}