import Container from "../ui/Container";
import SectionHeading from "../ui/SectionHeading";
import ContactCard from "../ui/ContactCard";
import { CONTACT_SECTIONS } from "@/lib/constants";

/**
 * ContactSection provides multiple channels for visitors to reach out. It
 * separates primary methods (catalogue, manager, phone) from secondary
 * platforms (channel, Instagram, YouTube). Cards link out using
 * appropriate protocols.
 */
export default function ContactSection() {
  return (
    <section
      id="contact"
      className="py-16 sm:py-24 border-t border-white/10"
    >
      <Container>
        <SectionHeading
          title="Buyurtma yoki hamkorlik uchun bog‘laning"
          description="Sizga qulay bo‘lgan kanal orqali biz bilan tez bog‘laning"
        />
        {/* Primary contacts */}
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {CONTACT_SECTIONS.primary.map((item) => (
            <ContactCard
              key={item.label}
              label={item.label}
              description={item.description}
              link={item.href}
            />
          ))}
        </div>
        {/* Secondary contacts */}
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {CONTACT_SECTIONS.secondary.map((item) => (
            <ContactCard
              key={item.label}
              label={item.label}
              description={item.description}
              link={item.href}
            />
          ))}
        </div>
      </Container>
    </section>
  );
}