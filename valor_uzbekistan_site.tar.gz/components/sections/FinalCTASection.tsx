import Container from "../ui/Container";
import Button from "../ui/Button";
import { FINAL_CTA } from "@/lib/constants";

/**
 * FinalCTASection provides a concluding call‑to‑action at the bottom of the
 * page, inviting visitors to place an order or initiate partnership.
 */
export default function FinalCTASection() {
  return (
    <section className="py-20 sm:py-28 border-t border-white/10">
      <Container className="text-center">
        <h2 className="text-3xl font-bold text-white sm:text-4xl">
          {FINAL_CTA.heading}
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-base text-brand-lightGray sm:text-lg">
          {FINAL_CTA.description}
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row sm:gap-6">
          <Button
            href={FINAL_CTA.primary.href}
            variant="primary"
            external
          >
            {FINAL_CTA.primary.label}
          </Button>
          <Button
            href={FINAL_CTA.secondary.href}
            variant="secondary"
            external
          >
            {FINAL_CTA.secondary.label}
          </Button>
        </div>
      </Container>
    </section>
  );
}