"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import clsx from "clsx";
import Button from "../ui/Button";
import { CONTACT_SECTIONS } from "@/lib/constants";

/**
 * Header component provides site navigation and a prominent call‑to‑action. It
 * adapts between desktop and mobile views, showing a burger menu on small
 * screens. The navigation links point to section IDs on the same page.
 */
export default function Header() {
  const [open, setOpen] = useState(false);
  const navItems = [
    { label: "Biz haqimizda", href: "#about" },
    { label: "Afzalliklar", href: "#benefits" },
    { label: "Yo'nalishlar", href: "#directions" },
    { label: "Jarayon", href: "#process" },
    { label: "Aloqa", href: "#contact" },
  ];
  // CTA link for catalogue from CONTACT_SECTIONS.primary
  const catalogHref = CONTACT_SECTIONS.primary.find(
    (c) => c.label.toLowerCase().includes('katalog')
  )?.href;
  return (
    <header className="fixed inset-x-0 top-0 z-50 backdrop-blur-md backdrop-saturate-150">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <Image
            src="/logo.png"
            alt="Valor Uzbekistan Logo"
            width={32}
            height={32}
            className="h-8 w-8 object-contain"
          />
          <span className="text-lg font-semibold text-white">Valor Uzbekistan</span>
        </Link>
        {/* Desktop nav */}
        <nav className="hidden lg:flex lg:items-center lg:gap-8">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-brand-lightGray hover:text-white"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        {/* CTA button for catalog */}
        {catalogHref && (
          <div className="hidden lg:block">
            <Button
              href={catalogHref}
              variant="primary"
              external
              className="whitespace-nowrap"
            >
              Katalogni ko'rish
            </Button>
          </div>
        )}
        {/* Mobile menu toggle */}
        <button
          className="lg:hidden text-brand-lightGray hover:text-white"
          onClick={() => setOpen(!open)}
          aria-label="Mobil menyu ochish"
        >
          {open ? (
            // Close icon
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="h-6 w-6"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          ) : (
            // Hamburger icon
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="h-6 w-6"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4.5 6.75h15m-15 5.25h15m-15 5.25h15"
              />
            </svg>
          )}
        </button>
      </div>
      {/* Mobile menu panel */}
      {open && (
        <div className="lg:hidden">
          <div className="space-y-6 px-4 pb-6 pt-2">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="block text-base font-medium text-brand-lightGray hover:text-white"
              >
                {item.label}
              </Link>
            ))}
            {catalogHref && (
              <Button
                href={catalogHref}
                external
                variant="primary"
                className="w-full"
                onClick={() => setOpen(false)}
              >
                Katalogni ko'rish
              </Button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}