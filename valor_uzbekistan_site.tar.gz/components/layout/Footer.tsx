import Image from "next/image";
import Link from "next/link";

/**
 * Footer component for the landing page. Minimal dark styling with
 * branding and copyright. Links can be added if needed later.
 */
export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-brand-dark py-8">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-4 px-4 sm:px-6 lg:flex-row lg:justify-between lg:px-8">
        <div className="flex items-center gap-2">
          <Image
            src="/logo.png"
            alt="Valor Uzbekistan Logo"
            width={32}
            height={32}
            className="h-8 w-8 object-contain"
          />
          <span className="text-sm font-semibold text-white">
            Valor Uzbekistan
          </span>
        </div>
        <p className="text-xs text-brand-lightGray">
          © {new Date().getFullYear()} Valor Uzbekistan. Barcha huquqlar himoyalangan.
        </p>
      </div>
    </footer>
  );
}