import Link from 'next/link';
import { ReactNode } from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'tertiary';

interface ButtonProps {
  href: string;
  children: ReactNode;
  variant?: ButtonVariant;
  external?: boolean;
  className?: string;
}

/*
  Generic Button component

  This component wraps Next.js's Link for internal navigation or an anchor tag
  for external links. It supports three variants:
  - primary: red background with white text
  - secondary: transparent background with white border
  - tertiary: simple link style for less emphasis
  Additional classes can be provided via the className prop. The button
  spans full width on small devices but auto sizes on larger screens.
*/
export default function Button({ href, children, variant = 'primary', external = false, className = '' }: ButtonProps) {
  const baseStyles =
    'inline-flex items-center justify-center rounded-full px-6 py-3 text-sm font-semibold transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2';

  const variants: Record<ButtonVariant, string> = {
    primary:
      'bg-brand-red text-brand-white hover:bg-brand-red/80 focus-visible:ring-brand-red',
    secondary:
      'border border-brand-red text-brand-red hover:bg-brand-red/10 focus-visible:ring-brand-red',
    tertiary: 'text-brand-red underline hover:text-brand-red/80 focus-visible:ring-brand-red',
  };

  const combined = `${baseStyles} ${variants[variant]} ${className}`;

  // If external, use anchor tag with rel attributes; otherwise, Next Link
  return external ? (
    <a href={href} target="_blank" rel="noopener noreferrer" className={combined}>
      {children}
    </a>
  ) : (
    <Link href={href} className={combined}>
      {children}
    </Link>
  );
}