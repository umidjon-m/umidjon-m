import Link from 'next/link';
import React from 'react';

/*
  ContactCard component

  Displays a call‑to‑action card with a label, description and a link. Used in
  the contact section to list various ways users can get in touch or follow
  Valor Uzbekistan. The card has a dark background and light border that
  changes colour on hover to match the brand accent. If an external link
  (e.g. tel: or https://) is provided, it will open in a new tab. Otherwise
  Next.js Link will handle internal navigation.
*/

export interface ContactCardProps {
  label: string;
  description: string;
  href: string;
}

export function ContactCard({ label, description, href }: ContactCardProps) {
  // Determine whether the link is external (http, tel:, mailto:)
  const isExternal = href.startsWith('http') || href.startsWith('tel:') || href.startsWith('mailto:');

  // Card content: reused for both anchor and Next.js Link
  const cardContent = (
    <div
      className="flex h-full flex-col justify-between gap-2 rounded-2xl border border-white/10 bg-brand-charcoal p-5 transition-colors duration-200 hover:border-brand-red hover:bg-brand-dark/70"
    >
      <div>
        <h3 className="text-lg font-semibold text-brand-white">{label}</h3>
        <p className="mt-1 text-sm leading-snug text-brand-lightGray">{description}</p>
      </div>
      <span className="mt-2 inline-flex items-center text-sm font-medium text-brand-red transition-colors duration-200 hover:text-brand-white">
        Batafsil&nbsp;→
      </span>
    </div>
  );
  // Wrap the card in an anchor for external links or Next.js Link for internal links
  if (isExternal) {
    return (
      <a
        href={href}
        target={href.startsWith('tel:') ? undefined : '_blank'}
        rel="noreferrer"
        className="block h-full"
      >
        {cardContent}
      </a>
    );
  }
  return (
    <Link href={href} className="block h-full">
      {cardContent}
    </Link>
  );
}