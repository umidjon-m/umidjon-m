import React from 'react';

/*
  Badge component

  Renders a pill‑shaped badge used to highlight small snippets of information
  such as trust signals or taglines. Uses the brand accent colour for the
  background with slightly transparent white text to stand out on dark
  backgrounds. Additional className can be passed for further styling.
*/

export interface BadgeProps {
  children: React.ReactNode;
  className?: string;
}

export function Badge({ children, className }: BadgeProps) {
  return (
    <span
      className={
        'inline-block rounded-full bg-brand-red/15 px-3 py-1 text-xs font-medium text-brand-red uppercase tracking-wide ' +
        (className ?? '')
      }
    >
      {children}
    </span>
  );
}