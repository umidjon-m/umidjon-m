"use client";

import clsx from "clsx";
import type { ReactNode } from "react";

/**
 * StatItem displays a numerical value and a short label. Used
 * primarily in the hero section to showcase key metrics such as
 * number of products, years of experience, etc. Accepts optional
 * custom class names for layout control.
 */
export default function StatItem({
  value,
  label,
  className,
}: {
  value: ReactNode;
  label: ReactNode;
  className?: string;
}) {
  return (
    <div className={clsx("flex flex-col", className)}>
      <dt className="text-3xl font-semibold text-white md:text-4xl">
        {value}
      </dt>
      <dd className="mt-1 text-sm text-brand-lightGray md:text-base">
        {label}
      </dd>
    </div>
  );
}