"use client";

import type { FC } from "react";
import Link from "next/link";

/*
  InfoCard

  A versatile card component for displaying succinct information such
  as benefit descriptions, product directions, or other highlighted
  content. It supports an optional link which, when provided, is
  rendered as a subtle call‑to‑action at the bottom of the card. The
  styling aligns with the dark premium aesthetic of the site.

  Props:
  - title: the heading of the card
  - description: supporting text to elaborate on the title
  - link: optional href for a call‑to‑action
  - linkLabel: optional text for the call‑to‑action
*/

interface InfoCardProps {
  title: string;
  description: string;
  link?: string;
  linkLabel?: string;
}

const InfoCard: FC<InfoCardProps> = ({ title, description, link, linkLabel }) => {
  const isExternal = link && (link.startsWith("http") || link.startsWith("mailto") || link.startsWith("tel"));
  return (
    <div className="flex flex-col h-full bg-charcoal border border-white/10 rounded-2xl p-6 hover:border-red-500 transition-colors">
      <div className="flex-1">
        <h4 className="text-xl font-semibold text-white mb-2">{title}</h4>
        <p className="text-gray-400 leading-relaxed">{description}</p>
      </div>
      {link && linkLabel && (
        <Link
          href={link}
          target={isExternal ? "_blank" : undefined}
          className="mt-4 inline-block text-red-500 hover:text-red-400 font-medium"
        >
          {linkLabel} <span aria-hidden="true">→</span>
        </Link>
      )}
    </div>
  );
};

export default InfoCard;