"use client";

import clsx from "clsx";
import type { ReactNode } from "react";

/**
 * Container component to constrain content width and apply responsive
 * padding. This utility helps maintain consistent margins across
 * sections. It accepts additional class names for custom spacing.
 */
export default function Container({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={clsx(
        "mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8", // responsive padding
        className,
      )}
    >
      {children}
    </div>
  );
}