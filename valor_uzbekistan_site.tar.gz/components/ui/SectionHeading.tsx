"use client";

import type { FC, ReactNode } from "react";

/*
  SectionHeading

  A reusable component to render section headers consistently across the
  site. It accepts an optional label (displayed in uppercase as a
  pre‑heading), a required title, and an optional description. This
  component centralises styling for headings to maintain a cohesive
  typographic hierarchy on every page.

  Props:
  - label: a small uppercase string displayed above the title
  - title: the main heading text for the section
  - description: a short paragraph providing additional context
*/

interface SectionHeadingProps {
  label?: string;
  title: string;
  description?: string;
  /** Optional children can be passed to insert custom content below the heading */
  children?: ReactNode;
}

const SectionHeading: FC<SectionHeadingProps> = ({
  label,
  title,
  description,
  children,
}) => {
  return (
    <div className="mb-12 text-center px-4 md:px-0">
      {label && (
        <h2 className="text-xs sm:text-sm font-semibold uppercase tracking-widest text-red-500 mb-3">
          {label}
        </h2>
      )}
      <h3 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
        {title}
      </h3>
      {description && (
        <p className="max-w-3xl mx-auto text-gray-400 text-base sm:text-lg">
          {description}
        </p>
      )}
      {children}
    </div>
  );
};

export default SectionHeading;