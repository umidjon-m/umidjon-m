/**
 * PostCSS configuration file
 *
 * We include Tailwind CSS and autoprefixer as PostCSS plugins. Tailwind
 * generates utility classes based on our configuration and autoprefixer
 * ensures vendor prefixes are added where necessary. Additional plugins
 * can be added here if needed.
 */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};