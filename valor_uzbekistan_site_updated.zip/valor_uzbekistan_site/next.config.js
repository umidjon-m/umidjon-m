/**
 * @type {import('next').NextConfig}
 *
 * This configuration enables React strict mode and leaves the default
 * image optimisation in place. Since all images used in this project are
 * stored locally in the `public` directory, additional configuration is
 * unnecessary. If you later choose to load remote images, define the
 * appropriate remotePatterns here.
 */
const nextConfig = {
  reactStrictMode: true,
};

module.exports = nextConfig;