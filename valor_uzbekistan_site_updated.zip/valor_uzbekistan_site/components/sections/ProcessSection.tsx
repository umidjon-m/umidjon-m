import Container from '../ui/Container';
import SectionHeading from '../ui/SectionHeading';
import { PROCESS_STEPS } from '@/lib/constants';

export default function ProcessSection() {
  return (
    <section id="process" className="border-b border-white/10 py-16 sm:py-24">
      <Container>
        <SectionHeading
          label="Jarayon"
          title="Biz bilan ishlash tartibi"
          description="Ta’minot jarayoni sodda, tez va oshkora"
        />

        <div className="mt-12 grid gap-6 lg:grid-cols-5">
          {PROCESS_STEPS.map((step, index) => (
            <div
              key={step.title}
              className="rounded-[1.75rem] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02))] p-6"
            >
              <div className="mb-6 flex h-11 w-11 items-center justify-center rounded-full bg-brand-red text-sm font-semibold text-white">
                {index + 1}
              </div>
              <h3 className="text-xl font-semibold text-white">{step.title}</h3>
              <p className="mt-3 text-base leading-8 text-brand-lightGray">{step.description}</p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}
