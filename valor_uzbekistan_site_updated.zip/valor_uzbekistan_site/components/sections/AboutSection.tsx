import Container from '../ui/Container';
import SectionHeading from '../ui/SectionHeading';
import { ABOUT_CONTENT } from '@/lib/constants';

export default function AboutSection() {
  return (
    <section id="about" className="border-b border-white/10 py-16 sm:py-24">
      <Container>
        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
          <SectionHeading
            align="left"
            label="Biz haqimizda"
            title={ABOUT_CONTENT.heading}
            description={ABOUT_CONTENT.description}
          />

          <div className="grid gap-5">
            <div className="rounded-[1.75rem] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02))] p-6">
              <div className="text-[11px] uppercase tracking-[0.22em] text-brand-lightGray">Nega bu muhim</div>
              <ul className="mt-4 space-y-4">
                {ABOUT_CONTENT.points.map((point) => (
                  <li key={point} className="flex items-start gap-3 text-base leading-8 text-brand-lightGray">
                    <span className="mt-3 h-2 w-2 rounded-full bg-brand-red" />
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              {ABOUT_CONTENT.highlights.map((item) => (
                <div key={item.label} className="rounded-[1.5rem] border border-white/10 bg-white/[0.03] p-5">
                  <div className="text-2xl font-semibold text-white">{item.value}</div>
                  <div className="mt-2 text-sm text-brand-lightGray">{item.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
