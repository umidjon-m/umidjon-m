import Container from '../ui/Container';
import SectionHeading from '../ui/SectionHeading';
import { ContactCard } from '../ui/ContactCard';
import { CONTACT_SECTIONS } from '@/lib/constants';

export default function ContactSection() {
  return (
    <section id="contact" className="border-b border-white/10 py-16 sm:py-24">
      <Container>
        <SectionHeading
          label="Aloqa"
          title="Buyurtma yoki hamkorlik uchun bog‘laning"
          description="Sizga qulay bo‘lgan kanal orqali biz bilan tez bog‘laning"
        />

        <div>
          <div className="mb-5 text-sm font-semibold uppercase tracking-[0.22em] text-brand-lightGray">
            Asosiy aloqa kanallari
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {CONTACT_SECTIONS.primary.map((item) => (
              <ContactCard
                key={item.label}
                label={item.label}
                description={item.description}
                href={item.href}
                priority="primary"
              />
            ))}
          </div>
        </div>

        <div className="mt-12">
          <div className="mb-5 text-sm font-semibold uppercase tracking-[0.22em] text-brand-lightGray">
            Qo‘shimcha platformalar
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {CONTACT_SECTIONS.secondary.map((item) => (
              <ContactCard
                key={item.label}
                label={item.label}
                description={item.description}
                href={item.href}
              />
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
