import Container from '../ui/Container';
import SectionHeading from '../ui/SectionHeading';
import InfoCard from '../ui/InfoCard';
import { DIRECTIONS } from '@/lib/constants';

export default function DirectionsSection() {
  return (
    <section id="directions" className="border-b border-white/10 py-16 sm:py-24">
      <Container>
        <SectionHeading
          label="Yo‘nalishlar"
          title="Mahsulot va aloqa yo‘llari bir joyda"
          description="Kerakli yo‘nalishni tanlang yoki darhol bog‘laning"
        />

        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <div className="mb-5 text-sm font-semibold uppercase tracking-[0.22em] text-brand-lightGray">
              Mahsulot yo‘nalishlari
            </div>
            <div className="grid gap-6 sm:grid-cols-2">
              {DIRECTIONS.products.map((item) => (
                <InfoCard key={item.title} eyebrow="Yo‘nalish" title={item.title} description={item.description} />
              ))}
            </div>
          </div>

          <div>
            <div className="mb-5 text-sm font-semibold uppercase tracking-[0.22em] text-brand-lightGray">
              Buyurtma yo‘llari
            </div>
            <div className="grid gap-6 sm:grid-cols-2">
              {DIRECTIONS.actions.map((item) => (
                <InfoCard
                  key={item.title}
                  eyebrow="Aloqa"
                  title={item.title}
                  description={item.description}
                  link={item.href}
                  linkLabel="Batafsil"
                />
              ))}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
