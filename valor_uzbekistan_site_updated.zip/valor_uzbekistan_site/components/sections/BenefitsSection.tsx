import Container from '../ui/Container';
import SectionHeading from '../ui/SectionHeading';
import InfoCard from '../ui/InfoCard';
import { BENEFITS } from '@/lib/constants';

export default function BenefitsSection() {
  return (
    <section id="benefits" className="border-b border-white/10 py-16 sm:py-24">
      <Container>
        <SectionHeading
          label="Afzalliklar"
          title="Nega aynan Valor Uzbekistan"
          description="Quyidagi afzalliklar bizning hamkorligimizni yanada ishonchli qiladi"
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
          {BENEFITS.map((benefit) => (
            <InfoCard
              key={benefit.title}
              eyebrow={benefit.eyebrow}
              title={benefit.title}
              description={benefit.description}
            />
          ))}
        </div>
      </Container>
    </section>
  );
}
