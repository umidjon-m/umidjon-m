import Image from 'next/image';
import Button from '../ui/Button';
import { Badge } from '../ui/Badge';
import StatItem from '../ui/StatItem';
import Container from '../ui/Container';
import { HERO_CONTENT } from '@/lib/constants';

export default function HeroSection() {
  return (
    <section id="hero" className="relative overflow-hidden border-b border-white/10 pt-32 sm:pt-40">
      <div aria-hidden="true" className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(226,28,35,0.18),transparent_38%),linear-gradient(180deg,rgba(39,4,6,0.9),rgba(11,11,13,1))]" />
      <Container className="relative z-10 grid items-center gap-12 py-20 lg:grid-cols-[1.05fr_0.95fr] lg:py-24">
        <div className="max-w-2xl">
          <Badge>{HERO_CONTENT.badge}</Badge>
          <div className="mt-6 flex items-center gap-4">
            <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl border border-white/10 bg-black/20 shadow-[0_0_30px_rgba(226,28,35,0.12)]">
              <Image src="/logo.png" alt="Valor Uzbekistan logosi" width={42} height={42} className="object-contain" priority />
            </div>
            <div>
              <div className="text-sm uppercase tracking-[0.26em] text-brand-lightGray">{HERO_CONTENT.subtitle}</div>
              <div className="mt-1 text-sm text-white/60">Qurilish uchun kuchli hamkor</div>
            </div>
          </div>

          <h1 className="mt-8 text-4xl font-semibold leading-[1.04] tracking-tight text-white sm:text-5xl lg:text-7xl">
            {HERO_CONTENT.title}
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-8 text-brand-lightGray sm:text-xl">
            {HERO_CONTENT.description}
          </p>
          <p className="mt-3 text-sm uppercase tracking-[0.22em] text-white/45">
            {HERO_CONTENT.supportText}
          </p>

          <div className="mt-8 flex flex-col gap-4 sm:flex-row">
            <Button href={HERO_CONTENT.ctaPrimary.href} variant="primary" external>
              {HERO_CONTENT.ctaPrimary.label}
            </Button>
            <Button href={HERO_CONTENT.ctaSecondary.href} variant="secondary" external>
              {HERO_CONTENT.ctaSecondary.label}
            </Button>
          </div>

          <dl className="mt-12 grid grid-cols-2 gap-8 lg:max-w-xl">
            {HERO_CONTENT.stats.map((stat) => (
              <StatItem key={stat.description} value={stat.title} label={stat.description} />
            ))}
          </dl>
        </div>

        <div className="relative">
          <div className="absolute inset-0 rounded-[2rem] bg-brand-red/10 blur-3xl" />
          <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-[linear-gradient(180deg,rgba(20,20,23,0.88),rgba(11,11,13,0.96))] p-6 shadow-[0_26px_70px_rgba(0,0,0,0.34)] backdrop-blur">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <div className="text-[11px] uppercase tracking-[0.24em] text-brand-lightGray">Distributor profili</div>
                <div className="mt-2 text-2xl font-semibold text-white">Ta’minot markazi</div>
              </div>
              <div className="rounded-full border border-brand-red/20 bg-brand-red/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.22em] text-brand-red">
                Premium
              </div>
            </div>

            <div className="grid gap-4">
              {HERO_CONTENT.panelItems.map((item) => (
                <div key={item.title} className="rounded-2xl border border-white/10 bg-black/20 p-4">
                  <div className="flex items-start gap-3">
                    <span className="mt-2 h-2.5 w-2.5 rounded-full bg-brand-red" />
                    <div>
                      <div className="text-lg font-semibold text-white">{item.title}</div>
                      <div className="mt-1 text-sm leading-7 text-brand-lightGray">{item.description}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 grid grid-cols-2 gap-4">
              <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                <div className="text-2xl font-semibold text-white">B2B</div>
                <div className="mt-1 text-sm text-brand-lightGray">hamkorlik modeli</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                <div className="text-2xl font-semibold text-white">Scale</div>
                <div className="mt-1 text-sm text-brand-lightGray">katta ta’minot hissi</div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
