import Container from '../ui/Container';
import Button from '../ui/Button';
import { FINAL_CTA } from '@/lib/constants';

export default function FinalCTASection() {
  return (
    <section className="py-20 sm:py-28">
      <Container className="text-center">
        <div className="rounded-[2rem] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02))] px-6 py-12 shadow-[0_20px_60px_rgba(0,0,0,0.2)] sm:px-10">
          <h2 className="text-3xl font-semibold text-white sm:text-4xl lg:text-5xl">
            {FINAL_CTA.heading}
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-8 text-brand-lightGray sm:text-lg">
            {FINAL_CTA.description}
          </p>
          <div className="mt-3 text-sm uppercase tracking-[0.22em] text-white/45">
            {FINAL_CTA.trustLine}
          </div>
          <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button href={FINAL_CTA.primary.href} variant="primary" external>
              {FINAL_CTA.primary.label}
            </Button>
            <Button href={FINAL_CTA.secondary.href} variant="secondary" external>
              {FINAL_CTA.secondary.label}
            </Button>
          </div>
        </div>
      </Container>
    </section>
  );
}
