import React from 'react';

export interface BadgeProps {
  children: React.ReactNode;
  className?: string;
}

export function Badge({ children, className }: BadgeProps) {
  return (
    <span
      className={
        'inline-block rounded-full bg-brand-red/15 px-3 py-1 text-xs font-medium text-brand-red uppercase tracking-wide ' +
        (className ?? '')
      }
    >
      {children}
    </span>
  );
}