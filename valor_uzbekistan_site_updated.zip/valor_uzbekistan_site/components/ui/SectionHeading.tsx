import type { ReactNode } from 'react';

interface SectionHeadingProps {
  label?: string;
  title: string;
  description?: string;
  align?: 'left' | 'center';
  children?: ReactNode;
}

export default function SectionHeading({
  label,
  title,
  description,
  align = 'center',
  children,
}: SectionHeadingProps) {
  const alignment = align === 'left' ? 'text-left items-start' : 'text-center items-center';

  return (
    <div className={`mb-12 flex flex-col ${alignment}`}>
      {label ? (
        <span className="mb-3 inline-flex rounded-full border border-brand-red/20 bg-brand-red/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.24em] text-brand-red">
          {label}
        </span>
      ) : null}
      <h2 className="max-w-4xl text-3xl font-semibold tracking-tight text-white sm:text-4xl lg:text-6xl">
        {title}
      </h2>
      {description ? (
        <p className="mt-4 max-w-3xl text-base leading-8 text-brand-lightGray sm:text-lg">
          {description}
        </p>
      ) : null}
      {children}
    </div>
  );
}
