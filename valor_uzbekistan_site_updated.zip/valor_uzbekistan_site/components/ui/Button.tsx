import Link from 'next/link';
import { MouseEventHandler, ReactNode } from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'tertiary';

interface ButtonProps {
  href: string;
  children: ReactNode;
  variant?: ButtonVariant;
  external?: boolean;
  className?: string;
  onClick?: MouseEventHandler<HTMLAnchorElement>;
}

export default function Button({ href, children, variant = 'primary', external = false, className = '', onClick }: ButtonProps) {
  const baseStyles =
    'inline-flex items-center justify-center rounded-full px-6 py-3.5 text-sm font-semibold transition duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-red focus-visible:ring-offset-2 focus-visible:ring-offset-brand-dark';

  const variants: Record<ButtonVariant, string> = {
    primary: 'bg-brand-red text-white shadow-[0_16px_40px_rgba(226,28,35,0.18)] hover:bg-[#ff2d33]',
    secondary: 'border border-brand-red/60 text-brand-red hover:bg-brand-red/10 hover:text-white',
    tertiary: 'text-brand-red underline-offset-4 hover:underline hover:text-white',
  };

  const combined = `${baseStyles} ${variants[variant]} ${className}`;

  if (external) {
    return (
      <a
        href={href}
        target={href.startsWith('tel:') ? undefined : '_blank'}
        rel="noopener noreferrer"
        className={combined}
        onClick={onClick}
      >
        {children}
      </a>
    );
  }

  return (
    <Link href={href} className={combined} onClick={onClick}>
      {children}
    </Link>
  );
}
