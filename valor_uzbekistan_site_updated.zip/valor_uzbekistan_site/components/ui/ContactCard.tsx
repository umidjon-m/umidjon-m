import Link from 'next/link';

export interface ContactCardProps {
  label: string;
  description: string;
  href: string;
  priority?: 'primary' | 'secondary';
}

export function ContactCard({ label, description, href, priority = 'secondary' }: ContactCardProps) {
  const isExternal = href.startsWith('http') || href.startsWith('tel:') || href.startsWith('mailto:');

  const content = (
    <div className={`flex h-full flex-col justify-between rounded-[1.75rem] border p-6 transition duration-300 ${priority === 'primary' ? 'border-brand-red/25 bg-[linear-gradient(180deg,rgba(226,28,35,0.08),rgba(255,255,255,0.02))] hover:border-brand-red/50' : 'border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02))] hover:border-brand-red/30'}`}>
      <div>
        <div className="mb-3 text-[11px] uppercase tracking-[0.22em] text-brand-lightGray">
          {priority === 'primary' ? 'Asosiy aloqa' : 'Platforma'}
        </div>
        <h3 className="text-2xl font-semibold text-white">{label}</h3>
        <p className="mt-3 text-base leading-8 text-brand-lightGray">{description}</p>
      </div>
      <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-brand-red">
        Batafsil <span aria-hidden="true">→</span>
      </span>
    </div>
  );

  if (isExternal) {
    return (
      <a href={href} target={href.startsWith('tel:') ? undefined : '_blank'} rel="noreferrer" className="block h-full">
        {content}
      </a>
    );
  }

  return (
    <Link href={href} className="block h-full">
      {content}
    </Link>
  );
}
