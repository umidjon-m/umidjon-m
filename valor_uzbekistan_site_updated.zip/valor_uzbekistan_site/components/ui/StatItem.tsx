'use client';

import clsx from 'clsx';
import type { ReactNode } from 'react';

export default function StatItem({
  value,
  label,
  className,
}: {
  value: ReactNode;
  label: ReactNode;
  className?: string;
}) {
  return (
    <div className={clsx('flex flex-col', className)}>
      <dt className="text-3xl font-semibold text-white md:text-4xl">
        {value}
      </dt>
      <dd className="mt-1 text-sm text-brand-lightGray md:text-base">
        {label}
      </dd>
    </div>
  );
}
