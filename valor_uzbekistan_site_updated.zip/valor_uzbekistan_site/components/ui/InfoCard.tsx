import Link from 'next/link';

type InfoCardProps = {
  title: string;
  description: string;
  link?: string;
  linkLabel?: string;
  eyebrow?: string;
};

export default function InfoCard({ title, description, link, linkLabel, eyebrow }: InfoCardProps) {
  const isExternal = !!link && (link.startsWith('http') || link.startsWith('mailto:') || link.startsWith('tel:'));

  return (
    <div className="group flex h-full flex-col rounded-[1.75rem] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02))] p-6 shadow-[0_10px_30px_rgba(0,0,0,0.12)] transition duration-300 hover:-translate-y-1 hover:border-brand-red/40 hover:shadow-[0_18px_40px_rgba(226,28,35,0.08)]">
      <div className="mb-4 h-px w-full bg-gradient-to-r from-brand-red/60 to-transparent" />
      {eyebrow ? <div className="mb-3 text-[11px] uppercase tracking-[0.22em] text-brand-lightGray">{eyebrow}</div> : null}
      <div className="flex-1">
        <h3 className="text-2xl font-semibold text-white">{title}</h3>
        <p className="mt-3 text-base leading-8 text-brand-lightGray">{description}</p>
      </div>
      {link && linkLabel ? (
        <Link
          href={link}
          target={isExternal ? '_blank' : undefined}
          rel={isExternal ? 'noreferrer' : undefined}
          className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-brand-red transition group-hover:text-white"
        >
          {linkLabel}
          <span aria-hidden="true">→</span>
        </Link>
      ) : null}
    </div>
  );
}
