import Image from 'next/image';
import Link from 'next/link';
import Container from '../ui/Container';
import { LINKS } from '@/lib/constants';

export default function Footer() {
  const quickLinks = [
    { label: 'Katalog', href: LINKS.catalogue },
    { label: 'Menejer', href: LINKS.manager },
    { label: 'Kanal', href: LINKS.channel },
  ];

  return (
    <footer className="border-t border-white/10 bg-brand-dark py-8">
      <Container className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03]">
            <Image src="/logo.png" alt="Valor Uzbekistan logo" width={24} height={24} className="object-contain" />
          </div>
          <div>
            <div className="font-semibold text-white">Valor Uzbekistan</div>
            <div className="text-sm text-brand-lightGray">Qurilish materiallari bo‘yicha ishonchli distribyutor</div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-5 text-sm text-brand-lightGray">
          {quickLinks.map((item) => (
            <Link key={item.label} href={item.href} target="_blank" className="transition hover:text-white">
              {item.label}
            </Link>
          ))}
        </div>

        <p className="text-sm text-brand-lightGray">
          © {new Date().getFullYear()} Valor Uzbekistan. Barcha huquqlar himoyalangan.
        </p>
      </Container>
    </footer>
  );
}
