'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import Button from '../ui/Button';
import Container from '../ui/Container';
import { CONTACT_SECTIONS } from '@/lib/constants';

export default function Header() {
  const [open, setOpen] = useState(false);

  const navItems = [
    { label: 'Biz haqimizda', href: '#about' },
    { label: 'Afzalliklar', href: '#benefits' },
    { label: "Yo‘nalishlar", href: '#directions' },
    { label: 'Jarayon', href: '#process' },
    { label: 'Aloqa', href: '#contact' },
  ];

  const catalogHref = CONTACT_SECTIONS.primary.find((c) =>
    c.label.toLowerCase().includes('katalog')
  )?.href;

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-brand-dark/80 backdrop-blur-xl">
      <Container className="flex items-center justify-between py-4">
        <Link href="/" className="flex items-center gap-3">
          <div className="relative flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03]">
            <Image
              src="/logo.png"
              alt="Valor Uzbekistan logo"
              width={28}
              height={28}
              className="object-contain"
              priority
            />
          </div>
          <div className="leading-none">
            <div className="text-lg font-semibold text-white">Valor Uzbekistan</div>
            <div className="mt-1 text-[11px] uppercase tracking-[0.24em] text-brand-lightGray">
              Distributor
            </div>
          </div>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-brand-lightGray transition hover:text-white"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:block">
          {catalogHref && (
            <Button href={catalogHref} variant="primary" external>
              Katalogni ko‘rish
            </Button>
          )}
        </div>

        <button
          type="button"
          className="rounded-xl border border-white/10 p-2 text-brand-lightGray transition hover:text-white lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Mobil menyu"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-6 w-6">
            {open ? (
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 6.75h15m-15 5.25h15m-15 5.25h15" />
            )}
          </svg>
        </button>
      </Container>

      {open && (
        <div className="border-t border-white/10 bg-brand-charcoal/95 lg:hidden">
          <Container className="space-y-5 py-5">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="block text-base font-medium text-brand-lightGray transition hover:text-white"
              >
                {item.label}
              </Link>
            ))}
            {catalogHref && (
              <Button href={catalogHref} external variant="primary" className="w-full" onClick={() => setOpen(false)}>
                Katalogni ko‘rish
              </Button>
            )}
          </Container>
        </div>
      )}
    </header>
  );
}
