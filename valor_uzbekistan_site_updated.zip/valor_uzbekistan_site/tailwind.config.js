/**
 * Tailwind configuration file
 *
 * This project uses Tailwind CSS for styling. We enable dark mode
 * by class and extend the default theme with a custom color palette
 * that reflects the Valor Uzbekistan brand. Primary colours are
 * dominated by dark shades with red accents. The font sizes and
 * spacing values rely on Tailwind defaults for consistency.
 */
module.exports = {
  darkMode: 'class',
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          // Primary brand colours
          red: '#E21C23',
          dark: '#0B0B0D',
          charcoal: '#141417',
          gray: '#1C1C21',
          lightGray: '#A1A1AA',
          white: '#F5F5F5',
        },
      },
      borderRadius: {
        'card': '1.5rem',
      },
    },
  },
  plugins: [],
};