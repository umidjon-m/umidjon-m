export const LINKS = {
  catalogue: 'https://t.me/valor_uz',
  manager: 'https://t.me/valor_menejer',
  channel: 'https://t.me/valor_uzbekistan',
  instagram: 'https://www.instagram.com/valor.uzbekistan',
  youtube: 'https://www.youtube.com/@valor.uzbekistan',
  taplink: 'https://taplink.cc/valor.uzbekistan',
  phone: '+998954608888',
};

export const HERO_CONTENT = {
  title: 'Qurilish materiallari bo‘yicha ishonchli distribyutor',
  subtitle: 'Valor Uzbekistan',
  badge: 'Dark premium distributor',
  description:
    'Do‘konlar, ustalar va qurilish obyektlari uchun 4000+ turdagi mahsulotlar, tezkor yetkazib berish va barqaror ta’minot yechimlarini taklif qilamiz.',
  ctaPrimary: {
    label: 'Katalogni ko‘rish',
    href: LINKS.catalogue,
  },
  ctaSecondary: {
    label: 'Menejer bilan bog‘lanish',
    href: LINKS.manager,
  },
  supportText: 'Telegram katalog va menejer orqali tezkor buyurtma oqimi',
  stats: [
    {
      title: '4000+',
      description: 'turdagi mahsulot',
    },
    {
      title: 'Tezkor',
      description: 'yetkazib berish',
    },
    {
      title: 'Ishonchli',
      description: 'ta’minot',
    },
    {
      title: 'Qulay',
      description: 'hamkorlik modeli',
    },
  ],
  panelItems: [
    {
      title: 'Mahsulot katalogi',
      description: 'Asosiy yo‘nalishlar va assortiment bilan tez tanishing.',
    },
    {
      title: 'Menejer bilan bog‘lanish',
      description: 'Buyurtma, narx va hamkorlik bo‘yicha tez javob oling.',
    },
    {
      title: 'Telefon orqali aloqa',
      description: 'Tezkor bog‘lanish va kelishuv uchun qulay kanal.',
    },
  ],
};

export const ABOUT_CONTENT = {
  heading: 'Kerakli mahsulotlar, qulay aloqa va ishonchli hamkorlik bir joyda',
  description:
    'Valor Uzbekistan qurilish materiallari bo‘yicha ishonchli distribyutor sifatida do‘konlar, ustalar va qurilish obyektlari uchun keng assortimentdagi mahsulotlarni taklif qiladi. Bizning maqsadimiz — mahsulot tanlashdan buyurtmagacha bo‘lgan jarayonni sodda, tez va ishonchli qilish.',
  points: [
    'Do‘konlar, ustalar va obyektlar uchun mos ta’minot modeli',
    'Telegram orqali tez aloqa va buyurtma jarayoni',
    'Qurilish materiallari va santexnika yo‘nalishlarida qulay assortiment',
  ],
  highlights: [
    { value: 'B2B', label: 'hamkorlik yondashuvi' },
    { value: '24/7', label: 'aloqa kanallari faol' },
    { value: 'Scale', label: 'barqaror ta’minot hissi' },
  ],
};

export const BENEFITS = [
  {
    title: '4000+ mahsulot',
    description: 'Qurilish va ta’mirlash yo‘nalishlari bo‘yicha keng assortiment bilan tez tanlov qiling.',
    eyebrow: 'Assortiment',
  },
  {
    title: 'Tezkor yetkazib berish',
    description: 'Buyurtmalarni imkon qadar tez va qulay tarzda yetkazishga yo‘naltirilgan xizmat.',
    eyebrow: 'Tezlik',
  },
  {
    title: 'Ishonchli ta’minot',
    description: 'Do‘konlar va obyektlar uchun barqaror hamkorlik va rejalashtirilgan ta’minot.',
    eyebrow: 'Ishonch',
  },
  {
    title: 'Qulay hamkorlik',
    description: 'Katalog, Telegram va telefon orqali buyurtma jarayonini soddalashtiradigan model.',
    eyebrow: 'Qulaylik',
  },
];

export const DIRECTIONS = {
  products: [
    {
      title: 'Qurilish materiallari',
      description: 'Asosiy va yordamchi qurilish mahsulotlari bo‘yicha keng yo‘nalish.',
    },
    {
      title: 'Santexnika',
      description: 'Santexnika ehtiyojlari uchun amaliy va tez topiladigan mahsulotlar.',
    },
  ],
  actions: [
    {
      title: 'Telegram katalog',
      description: 'Mahsulotlar bilan tanishing va kerakli yo‘nalishni tez toping.',
      href: LINKS.catalogue,
    },
    {
      title: 'Onlayn buyurtma',
      description: 'Menejer bilan tez bog‘lanib, buyurtma jarayonini boshlang.',
      href: LINKS.manager,
    },
  ],
};

export const PROCESS_STEPS = [
  {
    title: 'Katalogni ko‘ring',
    description: 'Mahsulot assortimenti va yo‘nalishlarini ko‘zdan kechiring.',
  },
  {
    title: 'Mahsulotni tanlang',
    description: 'Sizga mos mahsulot yoki kerakli yo‘nalishni aniqlang.',
  },
  {
    title: 'Menejerga yozing',
    description: 'Buyurtma va savollar bo‘yicha tez aloqa o‘rnating.',
  },
  {
    title: 'Buyurtmani tasdiqlang',
    description: 'Ma’lumotlarni aniqlashtirib, buyurtmani rasmiylashtiring.',
  },
  {
    title: 'Tez yetkazib oling',
    description: 'Mahsulotni qulay tarzda qabul qiling va ishni davom ettiring.',
  },
];

export const CONTACT_SECTIONS = {
  primary: [
    {
      label: 'Mahsulot katalogi',
      description: 'Keng assortimentni ko‘ring',
      href: LINKS.catalogue,
    },
    {
      label: 'Menejer bilan bog‘lanish',
      description: 'Buyurtma va savollar uchun',
      href: LINKS.manager,
    },
    {
      label: 'Telefon orqali bog‘lanish',
      description: 'Tez aloqa uchun qo‘ng‘iroq qiling',
      href: `tel:${LINKS.phone}`,
    },
  ],
  secondary: [
    {
      label: 'Telegram kanal',
      description: 'Yangiliklar va aksiyalar',
      href: LINKS.channel,
    },
    {
      label: 'Instagram',
      description: 'Bizni kuzating',
      href: LINKS.instagram,
    },
    {
      label: 'YouTube',
      description: 'Video ko‘rinishlar',
      href: LINKS.youtube,
    },
  ],
};

export const FINAL_CTA = {
  heading: 'Buyurtma yoki hamkorlik uchun hoziroq bog‘laning',
  description:
    'Kerakli mahsulotni katalog orqali tanlang yoki menejer bilan to‘g‘ridan-to‘g‘ri bog‘laning.',
  trustLine: 'Tez aloqa · Qulay buyurtma · Ishonchli ta’minot',
  primary: {
    label: 'Katalogni ko‘rish',
    href: LINKS.catalogue,
  },
  secondary: {
    label: 'Menejer bilan bog‘lanish',
    href: LINKS.manager,
  },
};
