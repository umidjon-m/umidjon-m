import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import HeroSection from '@/components/sections/HeroSection';
import AboutSection from '@/components/sections/AboutSection';
import BenefitsSection from '@/components/sections/BenefitsSection';
import DirectionsSection from '@/components/sections/DirectionsSection';
import ProcessSection from '@/components/sections/ProcessSection';
import ContactSection from '@/components/sections/ContactSection';
import FinalCTASection from '@/components/sections/FinalCTASection';

export default function Page() {
  return (
    <>
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <BenefitsSection />
        <DirectionsSection />
        <ProcessSection />
        <ContactSection />
        <FinalCTASection />
      </main>
      <Footer />
    </>
  );
}