import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';

const interFont = Inter({
  subsets: ['latin-ext'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Valor Uzbekistan | Qurilish materiallari bo‘yicha ishonchli distribyutor',
  description:
    '4000+ mahsulot, tezkor yetkazib berish va ishonchli ta’minot. Valor Uzbekistan qurilish materiallari va santexnika mahsulotlari bo‘yicha ishonchli distribyutor.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="uz" className="dark">
      <body
        className={`${interFont.className} min-h-screen overflow-x-hidden bg-brand-dark text-brand-white`}
      >
        {children}
      </body>
    </html>
  );
}
